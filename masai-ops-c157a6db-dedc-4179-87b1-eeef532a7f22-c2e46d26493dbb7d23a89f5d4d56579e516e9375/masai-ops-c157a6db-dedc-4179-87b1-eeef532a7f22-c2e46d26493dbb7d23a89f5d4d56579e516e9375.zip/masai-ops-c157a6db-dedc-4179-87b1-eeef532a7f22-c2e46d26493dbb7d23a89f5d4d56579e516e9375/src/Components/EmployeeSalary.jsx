import React from 'react'

export default function EmployeeSalary() {
    return (
        <div data-testid="employee-salary"> salary </div>
    )
}
