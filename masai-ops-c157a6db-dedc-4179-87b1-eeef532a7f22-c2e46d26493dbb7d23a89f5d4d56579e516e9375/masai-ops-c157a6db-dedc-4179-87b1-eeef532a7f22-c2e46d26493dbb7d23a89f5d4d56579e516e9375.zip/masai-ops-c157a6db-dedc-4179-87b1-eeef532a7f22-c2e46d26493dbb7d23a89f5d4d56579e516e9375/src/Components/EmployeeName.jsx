import React from 'react'

export default function EmployeeName() {
    return (
        <div data-testid="employee-name"> name </div>
    )
}
